package com.example.weather_biyke.remote_data;

import com.example.weather_biyke.models.Model;
import com.example.weather_biyke.models.WeatherModel;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface WeatherApi {
    String URL_KEY = "c7cbcd6c61c40b0f1ca87eb1a5e6b783" ;
    String BASE_URL  = "https://api.openweathermap.org";

    @GET("/data/2.5/weather")
    Call<Model> getCurrentWeather(
            @Query("q") String name,
            @Query("appid") String key);


    @GET("/data/2.5/weather/?q=London&appid=c7cbcd6c61c40b0f1ca87eb1a5e6b783")
    Call<WeatherModel> getWeather(
            @Query("q") String name,
            @Query("appid") String key);

}
